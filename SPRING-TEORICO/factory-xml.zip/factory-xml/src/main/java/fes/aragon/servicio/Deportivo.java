package fes.aragon.servicio;

public class Deportivo implements ModeloCoche{
    @Override
    public void crear() {
        System.out.println("Deportivoo");
    }
}
