package fes.aragon.model;

public class PlanificacionProyectos implements Actividades {
    @Override
    public void realiza() {
        System.out.println("Planificacion de proyectos");
    }
}
