package fes.aragon.model;

public class IntercambioConocimientos implements Actividades{
    @Override
    public void realiza() {
        System.out.println("Intercambio de conocimientos");
    }
}
