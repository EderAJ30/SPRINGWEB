package fes.aragon.servicio;

public class TodoTerreno implements ModeloCoche{
    @Override
    public void crear() {
        System.out.println("Todo Terrenoo");
    }
}
