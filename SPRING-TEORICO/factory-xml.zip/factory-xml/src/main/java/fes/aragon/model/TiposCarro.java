package fes.aragon.model;

public enum TiposCarro {
    DEPORTIVO,FAMILIAR,TODOTERRENO
}
