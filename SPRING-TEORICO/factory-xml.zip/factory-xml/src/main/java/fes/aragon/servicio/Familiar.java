package fes.aragon.servicio;

public class Familiar implements ModeloCoche{
    @Override
    public void crear() {
        System.out.println("Familiarr");
    }
}
