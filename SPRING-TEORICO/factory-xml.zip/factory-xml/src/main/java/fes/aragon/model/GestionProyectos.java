package fes.aragon.model;

public class GestionProyectos implements Actividades {
    @Override
    public void realiza() {
        System.out.println("Gestion de proyectos");
    }
}