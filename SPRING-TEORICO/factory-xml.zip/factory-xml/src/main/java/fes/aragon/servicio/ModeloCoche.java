package fes.aragon.servicio;

public interface ModeloCoche {
    void crear();
}
