package fes.aragon.model;

public interface Actividades {
    void realiza();
}
